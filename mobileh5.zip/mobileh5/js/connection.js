/**
 * Created by chao on 2016/7/5.
 */
      var web_url="http://www.juyoufuli.com";
// var web_url="http://192.168.0.54";
// var web_url="http://jy.com";